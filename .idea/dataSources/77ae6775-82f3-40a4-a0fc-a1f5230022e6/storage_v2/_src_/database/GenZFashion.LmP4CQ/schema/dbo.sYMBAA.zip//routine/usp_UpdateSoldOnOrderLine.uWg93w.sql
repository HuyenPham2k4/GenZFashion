CREATE PROCEDURE [dbo].[usp_UpdateSoldOnOrderLine]
AS
BEGIN
    SET NOCOUNT ON;

    -- Cập nhật cột Sold trong bảng Variation
    UPDATE v
    SET v.Sold = (
        SELECT SUM(ol.Quantity)
        FROM [dbo].[OrderLine] ol
        WHERE ol.VariationID = v.ID AND ol.Status = 1
    )
    FROM [dbo].[Variation] v
    WHERE v.ID IN (
        SELECT DISTINCT VariationID
        FROM [dbo].[OrderLine] -- Lấy tất cả các VariationID hiện có trong OrderLine để cập nhật
    );
END;
go

