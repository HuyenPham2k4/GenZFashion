CREATE TRIGGER [dbo].[trg_UpdateStatusOnZeroQuantity]
ON [dbo].[Variation]
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Cập nhật Status thành 0 khi số lượng = 0
    UPDATE v
    SET v.Status = 0
    FROM [dbo].[Variation] v
    INNER JOIN inserted i ON v.ID = i.ID
    WHERE i.Quantity = 0;
    
    -- Cập nhật Status thành 1 khi số lượng > 0
    UPDATE v
    SET v.Status = 1
    FROM [dbo].[Variation] v
    INNER JOIN inserted i ON v.ID = i.ID
    WHERE i.Quantity > 0;
END;
go

