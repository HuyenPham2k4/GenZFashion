

create TRIGGER [dbo].[trg_UpdateTotalAmountAndPayment]
ON [dbo].[OrderLine]
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OrderID INT;
    DECLARE @TotalAmount DECIMAL(12, 2);

    -- Xử lý cả INSERT / UPDATE / DELETE chung
    IF EXISTS (SELECT 1 FROM inserted) OR EXISTS (SELECT 1 FROM deleted)
    BEGIN
        -- Ưu tiên lấy OrderID từ inserted, nếu không có thì lấy từ deleted
        SELECT TOP 1 @OrderID = OderID FROM inserted;
        IF @OrderID IS NULL
            SELECT TOP 1 @OrderID = OderID FROM deleted;

        -- Tính tổng số tiền
        SELECT @TotalAmount = ISNULL(SUM(Price), 0)
        FROM OrderLine
        WHERE OderID = @OrderID;

        -- Gán tổng số tiền vào cả Total_Amount và Total_Payment
        UPDATE POSOder
        SET Total_Amount = @TotalAmount,
            Total_Payment = @TotalAmount
        WHERE ID = @OrderID;
    END
END;
go

